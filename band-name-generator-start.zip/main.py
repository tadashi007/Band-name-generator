print("Welcome to Band name generator !")
City=input("Which city are you from ? :\n")
Pet=input("Whats your pet name ? :\n")
print("your band name could be "+ City + " "+ Pet)
